import Navbar from "@/src/components/Navbar";
import Hero from "@/src/components/Hero";
import TrustedBy from "@/src/components/TrustedBy";
import FocusAreas from "@/src/components/FocusAreas";
import About from "@/src/components/About";
import Contact from "@/src/components/Contact";
import Footer from "@/src/components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-white selection:bg-accent/30 selection:text-primary">
      <Navbar />
      <main>
        <Hero />
        <TrustedBy />
        <FocusAreas />
        <About />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
