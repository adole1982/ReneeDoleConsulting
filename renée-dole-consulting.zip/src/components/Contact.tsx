import { motion } from "motion/react";
import { Button } from "@/src/components/ui/button";
import { Input } from "@/src/components/ui/input";
import { Textarea } from "@/src/components/ui/textarea";
import { Label } from "@/src/components/ui/label";
import { Mail, Phone, MapPin } from "lucide-react";

export default function Contact() {
  return (
    <section id="individual" className="py-24 bg-primary text-white">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-20">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="w-full lg:w-1/3"
          >
            <h2 className="text-4xl font-light tracking-tight mb-8">
              LET'S <span className="font-medium">CONNECT.</span>
            </h2>
            <p className="text-white/70 mb-12 leading-relaxed">
              Ready to optimize your impact? Reach out today to schedule a strategic audit or learn more about our services.
            </p>
            
            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center shrink-0">
                  <Mail className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <p className="text-xs font-bold tracking-widest text-white/50 uppercase mb-1">Email</p>
                  <p className="text-lg">hello@reneedole.com</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center shrink-0">
                  <Phone className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <p className="text-xs font-bold tracking-widest text-white/50 uppercase mb-1">Phone</p>
                  <p className="text-lg">+1 (555) 123-4567</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center shrink-0">
                  <MapPin className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <p className="text-xs font-bold tracking-widest text-white/50 uppercase mb-1">Office</p>
                  <p className="text-lg">San Francisco, CA</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="w-full lg:w-2/3 bg-white p-8 md:p-12 rounded-none text-primary"
          >
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="first-name" className="text-xs font-bold tracking-widest uppercase">First Name</Label>
                  <Input id="first-name" placeholder="Jane" className="rounded-none border-gray-200 focus:border-primary transition-colors" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="last-name" className="text-xs font-bold tracking-widest uppercase">Last Name</Label>
                  <Input id="last-name" placeholder="Doe" className="rounded-none border-gray-200 focus:border-primary transition-colors" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="email" className="text-xs font-bold tracking-widest uppercase">Email Address</Label>
                <Input id="email" type="email" placeholder="jane@example.com" className="rounded-none border-gray-200 focus:border-primary transition-colors" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="subject" className="text-xs font-bold tracking-widest uppercase">Subject</Label>
                <Input id="subject" placeholder="Executive Coaching Inquiry" className="rounded-none border-gray-200 focus:border-primary transition-colors" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="message" className="text-xs font-bold tracking-widest uppercase">Message</Label>
                <Textarea id="message" placeholder="How can we help you?" className="min-h-[150px] rounded-none border-gray-200 focus:border-primary transition-colors" />
              </div>
              <Button className="w-full md:w-fit bg-primary text-white hover:bg-primary/90 rounded-none px-12 py-6 text-sm tracking-[0.2em] font-bold">
                SEND MESSAGE
              </Button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
