import { motion } from "motion/react";
import { Button } from "@/src/components/ui/button";

export default function Hero() {
  return (
    <section id="home" className="relative min-h-[85vh] flex items-stretch overflow-hidden mt-20">
      {/* Background Image Container */}
      <div className="absolute inset-0 z-0">
        <motion.div 
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.5 }}
          className="h-full w-full"
        >
          <img 
            src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=1600" 
            alt="Renée Dole" 
            className="h-full w-full object-cover object-[75%_center]"
            referrerPolicy="no-referrer"
          />
        </motion.div>
      </div>

      {/* Navy Diagonal Overlay */}
      <div 
        className="absolute inset-0 z-10 bg-primary hidden md:block"
        style={{ 
          clipPath: "polygon(0 0, 55% 0, 40% 100%, 0% 100%)" 
        }}
      ></div>

      {/* Mobile Overlay */}
      <div className="absolute inset-0 z-10 bg-primary/90 md:hidden"></div>

      {/* Content Container */}
      <div className="container mx-auto px-6 relative z-20 flex items-center">
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="max-w-2xl py-20 text-white"
        >
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-light tracking-tight mb-8 leading-[1.1]">
            OPTIMIZE <br />
            <span className="font-medium">YOUR IMPACT.</span>
          </h1>
          <p className="text-lg md:text-xl font-light text-white/80 max-w-md mb-10 leading-relaxed">
            Renee Dole specializes in executive coaching, career consulting, and facilitation of group professional development. Renee brings extensive experience and expertise to provide tailored client solutions with meaningful results.
          </p>
          <Button 
            variant="outline" 
            className="w-fit border-white text-white hover:bg-white hover:text-primary rounded-none px-8 py-6 text-sm tracking-[0.2em] font-medium transition-all duration-300"
          >
            BOOK STRATEGIC AUDIT
          </Button>
        </motion.div>
      </div>

      {/* Large "C" background element */}
      <div className="absolute top-1/2 right-0 -translate-y-1/2 translate-x-1/4 text-[40rem] font-bold text-primary/5 select-none pointer-events-none hidden lg:block z-0">
        C
      </div>
    </section>
  );
}
