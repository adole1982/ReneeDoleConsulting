import { Linkedin, Twitter, Instagram } from "lucide-react";

export default function Footer() {
  return (
    <footer className="py-12 bg-white border-t border-gray-100">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex flex-col items-center md:items-start">
            <span className="text-xl font-light tracking-widest text-primary leading-tight">
              RENÉE DOLE
            </span>
            <span className="text-[8px] tracking-[0.3em] text-primary/70 font-medium -mt-1">
              CONSULTING
            </span>
          </div>

          <div className="flex items-center space-x-6">
            <a href="#" className="text-primary/40 hover:text-primary transition-colors">
              <Linkedin className="h-5 w-5" />
            </a>
            <a href="#" className="text-primary/40 hover:text-primary transition-colors">
              <Twitter className="h-5 w-5" />
            </a>
            <a href="#" className="text-primary/40 hover:text-primary transition-colors">
              <Instagram className="h-5 w-5" />
            </a>
          </div>

          <p className="text-[10px] tracking-widest text-primary/40 font-medium uppercase">
            © {new Date().getFullYear()} RENÉE DOLE CONSULTING. ALL RIGHTS RESERVED.
          </p>
        </div>
      </div>
    </footer>
  );
}
