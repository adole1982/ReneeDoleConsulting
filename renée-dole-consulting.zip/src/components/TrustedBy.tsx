import { motion } from "motion/react";

const partners = [
  "GLOBAL TECH",
  "FINANCIAL SERVICES",
  "STRATEGY FIRM",
  "GLOBAL TECH IT",
  "TEAM FOR GROUP",
  "GLOBAL TECH",
];

export default function TrustedBy() {
  return (
    <section className="py-16 bg-white border-b border-gray-100">
      <div className="container mx-auto px-6">
        <p className="text-center text-[10px] tracking-[0.4em] font-bold text-primary/40 mb-10 uppercase">
          Trusted By
        </p>
        <div className="flex flex-wrap justify-center items-center gap-x-12 gap-y-8 md:gap-x-20">
          {partners.map((partner, index) => (
            <motion.span
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="text-sm md:text-base font-semibold tracking-widest text-primary/60 hover:text-primary transition-colors cursor-default"
            >
              {partner}
            </motion.span>
          ))}
        </div>
      </div>
    </section>
  );
}
